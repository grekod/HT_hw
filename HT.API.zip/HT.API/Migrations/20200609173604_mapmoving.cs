﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HT.API.Migrations
{
    public partial class mapmoving : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
